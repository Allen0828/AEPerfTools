package com.aidejiayuan.gospel.service;


import com.aidejiayuan.gospel.Vo.GiftVo;

import java.util.List;

public interface GiftService {

    public void insert(GiftVo gift);

    public List<GiftVo> loadFeedGiftById(int id);

    public List<GiftVo> loadGiftsByBeneficiaryId(int beneficiaryId);
}
