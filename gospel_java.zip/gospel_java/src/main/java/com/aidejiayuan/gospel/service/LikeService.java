package com.aidejiayuan.gospel.service;

import com.aidejiayuan.gospel.Vo.Like;

import java.util.List;

public interface LikeService {

    public void insert(Like like);

    public Boolean isLikeFeed(int userId, int feedId);
    public Boolean isLikeComment(int userId, int commentId);

    public void unLikeFeed(int userId, int feedId);
    public void unLikeComment(int userId, int commentId);

    public List<Like> loadUserLikeFeeds(int userId);
}
