package com.aidejiayuan.gospel.service;


import com.aidejiayuan.gospel.Vo.Report;

public interface ReportService {

    public void insert(Report report);

}
