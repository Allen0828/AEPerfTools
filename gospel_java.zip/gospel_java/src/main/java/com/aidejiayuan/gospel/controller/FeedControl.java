package com.aidejiayuan.gospel.controller;


import com.aidejiayuan.gospel.Vo.Feed;
import com.aidejiayuan.gospel.Vo.File;
import com.aidejiayuan.gospel.Vo.User;
import com.aidejiayuan.gospel.Vo.UserVisibleInfo;
import com.aidejiayuan.gospel.mapper.FeedMapper;
import com.aidejiayuan.gospel.mapper.FileMapper;
import com.aidejiayuan.gospel.mapper.UserMapper;
import com.aidejiayuan.gospel.service.FeedService;
import com.aidejiayuan.gospel.service.FileService;
import com.aidejiayuan.gospel.service.LikeService;
import com.aidejiayuan.gospel.service.UserService;
import com.aidejiayuan.gospel.tools.annotation.UserLoginToken;
import com.aidejiayuan.gospel.tools.utils.DataMap;
import com.auth0.jwt.JWT;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@Slf4j
@RestController
public class FeedControl {

    @Autowired
    FeedService feedService;
    @Autowired
    UserService userService;
    @Autowired
    FileService fileService;
    @Autowired
    LikeService likeService;



    @GetMapping("api/feed/findById")
    public DataMap findFeedById(@RequestHeader("token") String token, @RequestParam("id") int id) {
        Feed vo = feedService.findFeedById(id);
        if (vo != null) {
            User userVo = userService.findUserById(vo.getAuthorId());
            UserVisibleInfo info = new UserVisibleInfo();
            info.setUserVo(userVo);
            vo.setAuthor(info);
            List<File> vos = fileService.findFiles(id, "Feed");
            vo.setFileVos(vos);
            // 判断用户是否已喜欢
            int userId = Integer.parseInt(JWT.decode(token).getAudience().get(0));
            if (userId > 0) {
                vo.setLike(likeService.isLikeFeed(userId, id));
            }
            return DataMap.success(vo);
        }
        return DataMap.error("没有此Feed");
    }



    // 发布
    @UserLoginToken
    @PostMapping("api/feed/add")
    public DataMap feedAdd(@RequestHeader("token") String token, @RequestBody Map<String, Object> map) {
        int userId = Integer.parseInt(JWT.decode(token).getAudience().get(0));
        List<Integer> imgWidths = (List<Integer>) map.get("imgWidths[]");
        List<Integer> imgHeights = (List<Integer>) map.get("imgHeights[]");
        List<String> imgDescs = (List<String>) map.get("imgDescs[]");
        List<String> imgNames = (List<String>) map.get("imgNames[]");
        String title = (String) map.get("title");
        String message = (String) map.get("message");
        Integer second = (Integer) map.get("second");
        // 先发布 获取feedId
        Feed newVo = new Feed();
        if (second > 0) {
            newVo.setNewFeed(title,message,userId,"VIDEO", 120);
        } else {
            newVo.setNewFeed(title,message,userId,"IMAGE", 120);
        }
        Integer feedId = feedService.addFeed(newVo);
        for (int i = 0; i < imgNames.size(); i++) {
            File vo = new File();
            if (imgWidths.get(i) == -1) {
                // 视频
                vo.setFile(newVo.getId(),imgNames.get(i),imgNames.get(i),imgWidths.get(i),imgHeights.get(i),imgDescs.get(i),"video/mp4",second,"FEED");
            } else {
                vo.setFile(newVo.getId(),imgNames.get(i),imgNames.get(i),imgWidths.get(i),imgHeights.get(i),imgDescs.get(i),"image/*",0,"FEED");
            }
            fileService.addFile(vo);
        }
        return DataMap.success(newVo.getId());
    }

    // 更新分数 必须要管理
    @UserLoginToken
    @PostMapping("api/feed/updateScore")
    public DataMap updateFeedScore(@RequestHeader("token") String token, @RequestBody Map<String, Object> map) {
        int userId = Integer.parseInt(JWT.decode(token).getAudience().get(0));
        User vo = userService.findUserById(userId);
        if (vo.getAdmin() == 0) {
            return DataMap.error("不是管理员");
        } else {
            int score = (int) map.get("score");
            int id = (int) map.get("id");
            feedService.updateFeedScore(id, score);
            return DataMap.success("OK");
        }
    }


}
