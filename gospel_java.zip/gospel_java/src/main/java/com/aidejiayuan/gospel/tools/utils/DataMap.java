package com.aidejiayuan.gospel.tools.utils;

import lombok.Data;

@Data
public class DataMap<T> {

    private String msg;
    // 0=请求失败 1=请求成功
    private Integer status;
    private T data;

    private DataMap() {
    }

    public static <T> DataMap<T> success(T data) {
        return commonResult(1,"请求成功", data);
    }

    public static <T> DataMap<T> error(String errorMsg) {
        return commonResult(0, errorMsg, null);
    }

    private static <T> DataMap<T> commonResult(Integer status, String errMsg, T data) {
        DataMap<T> result = new DataMap<>();
        result.setStatus(status);
        result.setMsg(errMsg);
        result.setData(data);
        return result;
    }

}
