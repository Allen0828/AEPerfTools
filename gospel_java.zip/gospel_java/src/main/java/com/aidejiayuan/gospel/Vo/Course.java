package com.aidejiayuan.gospel.Vo;


import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@NoArgsConstructor
@Data
public class Course {

    private int id;
    private int userId;
    private UserVisibleInfo userVo;

    private String title;
    private String descs;
    private String coverImg;

    private List<Lesson> lessonVos;

}
