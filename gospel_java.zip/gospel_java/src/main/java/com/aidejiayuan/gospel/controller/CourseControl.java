package com.aidejiayuan.gospel.controller;


import com.aidejiayuan.gospel.Vo.Course;
import com.aidejiayuan.gospel.Vo.CourseCommentVo;
import com.aidejiayuan.gospel.Vo.Lesson;
import com.aidejiayuan.gospel.service.CourseService;
import com.aidejiayuan.gospel.service.LessonService;
import com.aidejiayuan.gospel.tools.annotation.UserLoginToken;
import com.aidejiayuan.gospel.tools.utils.DataMap;
import com.auth0.jwt.JWT;
import com.github.pagehelper.PageHelper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@Slf4j
@RestController
public class CourseControl {

    @Autowired
    CourseService courseService;
    @Autowired
    LessonService lessonService;

    @GetMapping("api/course/findById")
    public DataMap findCourseById(@RequestParam("id") int id) {
        Course vo = courseService.findCourseById(id);
        if (vo != null) {
            return DataMap.success(vo);
        }
        return DataMap.error("course id is null");
    }

    @GetMapping("api/course/findLessonById")
    public DataMap findLeesonById(@RequestParam("id") int id) {
        Lesson vo = lessonService.findLessonById(id);
        if (vo != null) {
            return DataMap.success(vo);
        }
        return DataMap.error("lesson id is null");
    }

    @UserLoginToken
    @GetMapping("api/lesson/findCommentById")
    public DataMap loadCommentByLesson(@RequestHeader("token") String token, @RequestParam("lessonId") int lessonId, @RequestParam("page") int page) {
        int userId = Integer.parseInt(JWT.decode(token).getAudience().get(0));
        int pageNum = page;
        if (page == 0) { pageNum = 1; }
        int pageSize = 20;
        PageHelper.startPage(pageNum, pageSize);
        List<CourseCommentVo> vos = courseService.loadCommentByLeeson(lessonId, userId);
        return DataMap.success(vos);
    }

    @UserLoginToken
    @GetMapping("api/comment/loadCommentsById")
    public DataMap findCommentsById(@RequestParam("commentId") int commentId, @RequestParam("page") int page) {
        int pageNum = page;
        if (page == 0) { pageNum = 1; }
        int pageSize = 20;
        PageHelper.startPage(pageNum, pageSize);
        List<CourseCommentVo> vos = courseService.loadCommentsById(commentId);
        return DataMap.success(vos);
    }

    // 评论
    @UserLoginToken
    @PostMapping("api/comment/add")
    public DataMap addLessonComment(@RequestHeader("token") String token, @RequestBody Map<String, Object> map) {
        int userId = Integer.parseInt(JWT.decode(token).getAudience().get(0));
        String type = (String) map.get("type");
        String content = (String) map.get("content");
        if (map.containsKey("replyToId")) {
            int entityId = (int) map.get("entityId");
            int replyToId = (int) map.get("replyToId");
            int replyToUserId = (int) map.get("replyToUserId");
            String replyToUserName = (String) map.get("replyToUserName");
            CourseCommentVo vo = new CourseCommentVo();
            vo.setReplyComment(userId,entityId,type,content,replyToUserName,replyToId,replyToUserId);
            courseService.addCommentCount(entityId);
            int id = courseService.insert(vo);
            return DataMap.success(vo.getId());
        } else if (map.containsKey("entityId")) {
            int entityId = (int) map.get("entityId");
            CourseCommentVo vo = new CourseCommentVo();
            vo.setComment(userId,entityId,type,content);
            courseService.addCommentCount(entityId);
            int id = courseService.insert(vo);
            return DataMap.success(vo.getId());
        } else {
            int lessonId = (int) map.get("lessonId");
            CourseCommentVo vo = new CourseCommentVo();
            vo.setLessonComment(userId,lessonId,type,content);
            int id = courseService.insert(vo);
            return DataMap.success(vo.getId());
        }
    }

}
