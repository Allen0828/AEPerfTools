package com.aidejiayuan.gospel.service.impl;

import com.aidejiayuan.gospel.Vo.Feed;
import com.aidejiayuan.gospel.Vo.File;
import com.aidejiayuan.gospel.Vo.GiftVo;
import com.aidejiayuan.gospel.Vo.UserVisibleInfo;
import com.aidejiayuan.gospel.mapper.GiftMapper;
import com.aidejiayuan.gospel.service.GiftService;
import com.aidejiayuan.gospel.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class GiftServiceImpl implements GiftService {

    @Autowired
    GiftMapper giftMapper;
    @Autowired
    UserService userService;

    @Override
    public void insert(GiftVo gift) { giftMapper.insert(gift); }

    @Override
    public List<GiftVo> loadFeedGiftById(int id) {
        List<GiftVo> vos = giftMapper.loadFeedGiftById(id);
        for (GiftVo item: vos) {
            UserVisibleInfo user = new UserVisibleInfo();
            user.setUserVo(userService.findUserById(item.getUserId()));
            item.setUserVo(user);
        }
        return vos;
    }

    @Override
    public List<GiftVo> loadGiftsByBeneficiaryId(int beneficiaryId) {
        List<GiftVo> vos = giftMapper.loadGiftsByBeneficiaryId(beneficiaryId);
        for (GiftVo item: vos) {
            UserVisibleInfo user = new UserVisibleInfo();
            user.setUserVo(userService.findUserById(item.getUserId()));
            item.setUserVo(user);
        }
        return vos;
    }
}
