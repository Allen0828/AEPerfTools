package com.aidejiayuan.gospel.controller;


import com.aidejiayuan.gospel.Vo.User;
import com.aidejiayuan.gospel.Vo.Wallet;
import com.aidejiayuan.gospel.service.TokenService;
import com.aidejiayuan.gospel.service.UserService;
import com.aidejiayuan.gospel.service.WalletService;
import com.aidejiayuan.gospel.tools.utils.DataMap;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
@Slf4j
// 使用userService
public class LoginControl {

    @Autowired
    UserService userService;
    @Autowired
    TokenService tokenService;
    @Autowired
    WalletService walletService;

    @PostMapping("/api/login/register")
    public DataMap register(@RequestHeader("device") String device, @RequestBody Map<String, Object> map) {
        // 判断是否为手机号注册
        String phone = (String) map.get("phone");
        String password = (String) map.get("password");
        if (userService.findUserByPhone(phone) != null) {
            return DataMap.error("手机号已被注册");
        }
        User vo = new User();
        vo.setPassword(password);
        vo.setPhone(phone);
        vo.setUsername("用户"+phone.substring(7,11));
        vo.setGender("male");
        userService.insert(vo);
        User newUser = userService.findUserByPhone(phone);
        // 同时注册用户钱包
        Wallet wa = new Wallet();
        wa.setUserId(newUser.getId());
        wa.setBalance(0);
        wa.setDevice(device);
        walletService.insert(wa);
        if (newUser != null) {
            String token = tokenService.getToken(newUser);
            return DataMap.success(token);
        }
        return DataMap.error("网络错误");
    }

    @PostMapping("/api/login/login")
    public DataMap login(@RequestBody Map<String, Object> map) {
        // 判断是否有此用户
        String phone = (String) map.get("phone");
        String password = (String) map.get("password");
        if (userService.findUserByPhone(phone) == null) {
            return DataMap.error("此手机号还未注册，快去注册吧。");
        }
        User newUser = userService.findUserByPhone(phone);
        if (newUser != null) {
            String token = tokenService.getToken(newUser);
            return DataMap.success(token);
        }
        return DataMap.error("网络错误");
    }



}
