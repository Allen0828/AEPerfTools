package com.aidejiayuan.gospel.service.impl;


import com.aidejiayuan.gospel.Vo.User;
import com.aidejiayuan.gospel.mapper.UserMapper;
import com.aidejiayuan.gospel.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    UserMapper userMapper;

    @Override
    public User findUserByPhone(String phone) {
        return userMapper.findUserByPhone(phone);
    }

    @Override
    public User findUserById(int id) { return userMapper.findUserById(id); }

    @Override
    public User insert(User user) {
        userMapper.save(user);
        return user;
    }

    @Override
    public void updateUsername(int id, String username) { userMapper.updateUsername(id, username); }
    @Override
    public void updateUserGender(int id, String gender) { userMapper.updateUserGender(id, gender); }
    @Override
    public void updateUserFaithDate(int id, int faithDate) { userMapper.updateUserFaithDate(id, faithDate); }
    @Override
    public void updateUserChurchName(int id, String name) { userMapper.updateUserChurchName(id, name); }
    @Override
    public void updateUserAvatar(int id, String avatar) { userMapper.updateUserAvatar(id, avatar); }

}
