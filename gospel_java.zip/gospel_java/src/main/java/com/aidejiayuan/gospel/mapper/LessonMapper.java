package com.aidejiayuan.gospel.mapper;


import com.aidejiayuan.gospel.Vo.Lesson;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

import java.util.List;

@Mapper
@Repository
public interface LessonMapper {

    @Select("select * from course_lesson where id=#{id}")
    Lesson findLessonById(@Param("id") int id);

    @Select("select * from course_lesson where courseId=#{courseId}")
    List<Lesson> findLessonsByCourseId(@Param("courseId") int courseId);


}
