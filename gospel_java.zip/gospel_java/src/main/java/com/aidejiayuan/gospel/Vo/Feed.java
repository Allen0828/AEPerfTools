package com.aidejiayuan.gospel.Vo;


import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.List;

@NoArgsConstructor
@Data
public class Feed {

    private int id;
    // 作者Id
    private int authorId;
    private String title;
    private String descr;
    private String coverImg;
    private String feedType;
    private int pv;
//    @JsonFormat(shape=JsonFormat.Shape.STRING,pattern="yyyy-MM-dd HH:mm:ss",timezone="GMT+8")
    private Date createDate;
    private int likeCount;
    private int commentCount;
    private int rewardCount;
    private int score;
    private UserVisibleInfo author;
    // 内容
    private List<File> fileVos;

    // 是否喜欢
    private boolean like;


    // 新建时需要的数据
    public void setNewFeed(String title, String descr, int authorId, String feedType, int pv) {
        this.title = title;
        this.descr = descr;
        this.authorId = authorId;
        this.feedType = feedType;
        this.pv = pv;
    }
}
