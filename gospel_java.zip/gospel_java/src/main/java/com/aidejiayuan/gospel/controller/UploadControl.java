package com.aidejiayuan.gospel.controller;


import com.aidejiayuan.gospel.tools.annotation.UserLoginToken;
import com.aidejiayuan.gospel.tools.utils.DataMap;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartRequest;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.List;
import java.util.Map;

@Slf4j
@RestController
public class UploadControl {

    @UserLoginToken
    @PostMapping("api/upload/file")
    public DataMap uploadFile(MultipartRequest multipartRequest, @RequestParam("desc") String desc) throws IOException {
        MultipartFile file = multipartRequest.getFile("file");
        try {

            BufferedImage img = ImageIO.read(file.getInputStream());
            Integer width = img.getWidth();
            Integer height = img.getHeight();

            return DataMap.success(desc);
        } catch (IOException e) {
            e.printStackTrace();
            return DataMap.error("error");
        }
    }




}
