package com.aidejiayuan.gospel.mapper;


import com.aidejiayuan.gospel.Vo.Course;
import com.aidejiayuan.gospel.Vo.CourseCommentVo;
import com.aidejiayuan.gospel.Vo.User;
import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Repository;

import java.util.List;

@Mapper
@Repository
public interface CourseMapper {

    @Select("select * from course where id=#{id}")
    Course findCourseById(@Param("id") int id);

    @Select("select * from course order by id desc")
    List<Course> loadAllCourses();


    @Select("select * from course_comment where lessonId=#{lessonId} order by id desc")
    List<CourseCommentVo> loadCommentByLeeson(@Param("lessonId") int lessonId);

    @Select("select * from course_comment where entityId=#{commentId} and type=#{type} order by id desc")
    List<CourseCommentVo> loadCommentsById(@Param("commentId") int commentId, @Param("type") String type);

    @Select("select * from course_comment where entityId=#{entityId} order by id desc limit 0,1")
    CourseCommentVo findCommentByMaxTime(@Param("entityId") int entityId);

    // @Options 插入成功后 返回ID
    @Insert("insert into course_comment(type,submitId,entityId,content,replyToId,replyToUserId,replyToUserName,lessonId) values(#{type},#{submitId},#{entityId},#{content},#{replyToId},#{replyToUserId},#{replyToUserName},#{lessonId})")
    @Options(useGeneratedKeys=true, keyProperty="id", keyColumn="id")
    int save(CourseCommentVo vo);

    @Update("update course_comment set likeCount = likeCount + 1 where id=#{id}")
    void addLikeCount(@Param("id") int id);
    @Update("update course_comment set likeCount = likeCount - 1 where id=#{id}")
    void deleteLikeCount(@Param("id") int id);

    @Update("update course_comment set commentCount = commentCount + 1 where id=#{id}")
    void addCommentCount(@Param("id") int id);

}
