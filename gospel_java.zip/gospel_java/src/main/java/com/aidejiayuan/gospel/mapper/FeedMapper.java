package com.aidejiayuan.gospel.mapper;


import com.aidejiayuan.gospel.Vo.Feed;
import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Repository;

import java.util.List;

@Mapper
@Repository
public interface FeedMapper {

    @Select("select * from feed where id=#{id}")
    Feed findFeedById(@Param("id") int id);


    @Select("select * from feed where score > 0 order by case when score=5 then 5 end desc, case when score=3 then 3 end desc,id desc")
    List<Feed> loadAllFeed();
    // 最新发布
    @Select("select * from feed where score > 0 order by id desc")
    List<Feed> loadNewFeed();
    // 管理员查看待审核Feed
    @Select("select * from feed order by id desc")
    List<Feed> loadExamineFeed();

    // 更新数据
    @Update("update feed set likeCount = likeCount + 1 where id=#{id}")
    void updateLikeCount(@Param("id") int id);
    @Update("update feed set pv = pv + 1 where id=#{id}")
    void updatePvCount(@Param("id") int id);
    @Update("update feed set rewardCount = rewardCount + 1 where id=#{id}")
    void updateRewardCount(@Param("id") int id);
    @Update("update feed set score=#{score} where id=#{id}")
    void updateFeedScore(@Param("id") int id, @Param("score") int score);

    // 用户的发布
    @Select("select * from feed where authorId=#{authorId} order by id desc")
    List<Feed> loadFeedByAuthorId(@Param("authorId") int authorId);

//    @Insert("insert into course_comment(type,submitId,entityId) values(#{type},#{submitId},#{entityId})")

    // 发布 @Options 插入成功后 返回ID
    @Insert("insert into feed(title,descr,authorId,feedType,pv) values(#{title},#{descr},#{authorId},#{feedType},#{pv})")
    @Options(useGeneratedKeys=true, keyProperty="id", keyColumn="id")
    int addFeed(Feed vo);

}
