package com.aidejiayuan.gospel.Vo;


import lombok.Data;

import java.util.List;

@Data
public class Carousel {

    private List<ConfigureVo> banners;
    private List<ConfigureVo> modulars;
    private ConfigureVo adsense;

}
