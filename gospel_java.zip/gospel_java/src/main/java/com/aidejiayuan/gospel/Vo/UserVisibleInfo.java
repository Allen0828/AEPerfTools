package com.aidejiayuan.gospel.Vo;


import lombok.Data;

// 用户可见信息
@Data
public class UserVisibleInfo {

    private int id;
    private String phone;
    private String username;
    private String avatar;
    private String gender;
    private String churchName;
    private int likeCount;
    private int postCount;
    private int admin;

    // 只有登录用户自己可见
    private int walletBalance;

    public UserVisibleInfo setUserVo(User vo) {
        this.setId(vo.getId());
        this.setUsername(vo.getUsername());
        this.setAvatar(vo.getAvatar());
        this.setChurchName(vo.getChurchName());
        this.setGender(vo.getGender());
        this.setAdmin(vo.getAdmin());

        return this;
    }
    public UserVisibleInfo setUserWallet(Wallet wallet) {
        this.setWalletBalance(wallet.getBalance());
        return this;
    }
}
