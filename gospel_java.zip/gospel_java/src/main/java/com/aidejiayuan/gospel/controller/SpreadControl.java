package com.aidejiayuan.gospel.controller;


import com.aidejiayuan.gospel.Vo.*;
import com.aidejiayuan.gospel.mapper.FeedMapper;
import com.aidejiayuan.gospel.mapper.UserMapper;
import com.aidejiayuan.gospel.service.CourseService;
import com.aidejiayuan.gospel.service.FeedService;
import com.aidejiayuan.gospel.service.SpreadService;
import com.aidejiayuan.gospel.service.UserService;
import com.aidejiayuan.gospel.tools.annotation.UserLoginToken;
import com.aidejiayuan.gospel.tools.utils.DataMap;
import com.auth0.jwt.JWT;
import com.github.pagehelper.PageHelper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
@RestController
public class SpreadControl {
    // 此类 展示所有推荐的信息 如 首页轮播图 资源库列表等

    @Autowired
    SpreadService spreadService;
    @Autowired
    CourseService courseService;
    @Autowired
    UserService userService;


    // 信息配置
    @GetMapping("/api/spread/appConfig")
    public DataMap apiConfig() {
        HashMap<String, Object> map = new HashMap<>();
        map.put("showReward", false);
        map.put("version", "1.0.0");

        return DataMap.success(map);
    }


    // 首页banner和item
    @GetMapping("api/spread/findValidNow")
    public DataMap findValidNow() {
        Carousel vo = new Carousel();
        List<ConfigureVo> banners = spreadService.loadByType("banner");
        vo.setBanners(banners);
        List<ConfigureVo> items = spreadService.loadByType("modulars");
        vo.setModulars(items);
        List<ConfigureVo> ads = spreadService.loadByType("adsense");
        if (ads != null && ads.size() > 0 && ads.get(0) != null) {
            vo.setAdsense(ads.get(0));
        }
        return DataMap.success(vo);
    }

    // 首页推荐的FEED homePage
    @GetMapping("api/spread/homePage")
    public DataMap recommendHomePage(@RequestParam("page") int page) {
        int pageNum = page;
        if (page == 0) { pageNum = 1; }
        int pageSize = 5;
        PageHelper.startPage(pageNum, pageSize);
        List<Feed> vos = spreadService.loadRecommendFeed();
        if (vos != null) {
            return DataMap.success(vos);
        }
        return DataMap.error("error");
    }

    // 资源库展示信息
    @GetMapping("api/spread/Library")
    public DataMap recommendLibrary(@RequestParam("page") int page) {
        int pageNum = page;
        if (page == 0) { pageNum = 1; }
        int pageSize = 20;
        PageHelper.startPage(pageNum, pageSize);
        List<Course> vos = courseService.loadAllCourses();
        return DataMap.success(vos);
    }

    // 最新发布
    @UserLoginToken
    @GetMapping("api/spread/loadNewFeed")
    public DataMap loadNewFeed(@RequestHeader("token") String token, @RequestParam("page") int page) {
        int userId = Integer.parseInt(JWT.decode(token).getAudience().get(0));
        User vo = userService.findUserById(userId);
        if (vo.getAdmin() == 0) {
            int pageNum = page;
            if (page == 0) { pageNum = 1; }
            int pageSize = 20;
            PageHelper.startPage(pageNum, pageSize);
            List<Feed> vos = spreadService.loadNewFeed(0);
            return DataMap.success(vos);
        } else {
            int pageNum = page;
            if (page == 0) {
                pageNum = 1;
            }
            int pageSize = 20;
            PageHelper.startPage(pageNum, pageSize);
            List<Feed> vos = spreadService.loadNewFeed(1);
            return DataMap.success(vos);
        }
    }

}
