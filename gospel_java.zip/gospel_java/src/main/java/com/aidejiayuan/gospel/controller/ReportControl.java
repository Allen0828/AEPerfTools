package com.aidejiayuan.gospel.controller;

import com.aidejiayuan.gospel.Vo.Report;
import com.aidejiayuan.gospel.service.ReportService;
import com.aidejiayuan.gospel.tools.annotation.UserLoginToken;
import com.aidejiayuan.gospel.tools.utils.DataMap;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@Slf4j
@RestController
public class ReportControl {

    @Autowired
    ReportService reportService;

    // 举报
    @UserLoginToken
    @PostMapping("/api/report/report")
    public DataMap report(@RequestBody Map<String, Object> map) {
        String reportName = (String) map.get("reportName");
        String reportPhone = (String) map.get("reportPhone");
        String type = (String) map.get("type");
        String content = (String) map.get("content");
        int userId = (int) map.get("userId");
        Report vo = new Report();
        vo.setReport(userId, reportName, reportPhone, content, type);
        reportService.insert(vo);
        return DataMap.success("OK");
    }

}
