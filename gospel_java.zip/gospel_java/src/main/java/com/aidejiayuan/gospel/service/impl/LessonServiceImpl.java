package com.aidejiayuan.gospel.service.impl;

import com.aidejiayuan.gospel.Vo.Feed;
import com.aidejiayuan.gospel.Vo.File;
import com.aidejiayuan.gospel.Vo.Lesson;
import com.aidejiayuan.gospel.Vo.UserVisibleInfo;
import com.aidejiayuan.gospel.mapper.LessonMapper;
import com.aidejiayuan.gospel.service.FileService;
import com.aidejiayuan.gospel.service.LessonService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class LessonServiceImpl implements LessonService {

    @Autowired
    LessonMapper lessonMapper;
    @Autowired
    FileService fileService;

    @Override
    public Lesson findLessonById(int id) { return lessonMapper.findLessonById(id); }

    @Override
    public List<Lesson> findLessonsByCourseId(int courseId) {
        List<Lesson> vos = lessonMapper.findLessonsByCourseId(courseId);
        for (Lesson item: vos) {
            File vo = fileService.findFile(item.getId(), "COURSE_LESSON");
            item.setFileVo(vo);
        }
        return vos;
    }

}
