package com.aidejiayuan.gospel.controller;


import com.aidejiayuan.gospel.Vo.GiftVo;
import com.aidejiayuan.gospel.Vo.Wallet;
import com.aidejiayuan.gospel.service.FeedService;
import com.aidejiayuan.gospel.service.GiftService;
import com.aidejiayuan.gospel.service.WalletService;
import com.aidejiayuan.gospel.tools.annotation.UserLoginToken;
import com.aidejiayuan.gospel.tools.utils.DataMap;
import com.auth0.jwt.JWT;
import com.github.pagehelper.PageHelper;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@Slf4j
@RestController
public class GiftControl {

    @Autowired
    GiftService giftService;
    @Autowired
    WalletService walletService;
    @Autowired
    FeedService feedService;

    // 查看feed收到的所有礼物
    @UserLoginToken
    @GetMapping("api/gift/loadByFeedId")
    public DataMap loadGiftByFeed(@RequestParam("id") int id, @RequestParam("page") int page) {
        if (id < 1) {
            return DataMap.error("检查参数");
        }
        int pageNum = page;
        if (page == 0) { pageNum = 1; }
        int pageSize = 20;
        PageHelper.startPage(pageNum, pageSize);
        List<GiftVo> vos = giftService.loadFeedGiftById(id);
        return DataMap.success(vos);
    }

    // 查看自己收到的礼物
    @UserLoginToken
    @GetMapping("api/gift/loadMyGifts")
    public DataMap loadMyGift(@RequestHeader("token") String token, @RequestParam("page") int page) {
        int pageNum = page;
        if (page == 0) { pageNum = 1; }
        int pageSize = 20;
        PageHelper.startPage(pageNum, pageSize);
        int userId = Integer.parseInt(JWT.decode(token).getAudience().get(0));
        if (userId < 1) {
            return DataMap.error("检查参数");
        }
        List<GiftVo> vos = giftService.loadGiftsByBeneficiaryId(userId);
        return DataMap.success(vos);
    }

    // 给Feed赠送礼物
    @UserLoginToken
    @PostMapping("api/gift/giveByFeed")
    public DataMap giveGiftByFeed(@RequestHeader("token") String token, @RequestBody Map<String, Object> map) {
        int userId = Integer.parseInt(JWT.decode(token).getAudience().get(0));
        int feedId = (int) map.get("feedId");
        int beneficiaryId = (int) map.get("beneficiaryId");
        int count = (int) map.get("count");
        if (userId < 1 || feedId < 1 || beneficiaryId < 1 || count < 1) {
            return DataMap.error("检查参数");
        }
        Wallet userWallet = walletService.findWalletByUserId(userId);
        int userBalance = userWallet.getBalance();
        if (userBalance < count*1) {
            return DataMap.error("余额不足");
        }
        int price = count * 1;

        walletService.updateBalance(userId, price, 0);
        // 给收益人增加
        walletService.updateCashCoupon(beneficiaryId, price, 1);
        GiftVo vo = new GiftVo();
        vo.setFeedGift(userId, beneficiaryId, feedId, count);
        giftService.insert(vo);
        feedService.updateFeedReward(feedId);
        return DataMap.success("OK");
    }

}
