package com.aidejiayuan.gospel.service;


import com.aidejiayuan.gospel.Vo.File;

import java.util.List;

public interface FileService {

    List<File> findFiles(int entityId, String usages);

    File findFile(int entityId, String usages);

    void addFile(File vo);

}
