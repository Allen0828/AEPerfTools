package com.aidejiayuan.gospel.mapper;


import com.aidejiayuan.gospel.Vo.Wallet;
import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Repository;

@Mapper
@Repository
public interface WalletMapper {

    @Select("select * from wallet where userId=#{userId}")
    Wallet findWalletByUserId(@Param("userId") int userId);

    /// 注意不要多 } 空格 等符号
    @Insert("insert into wallet(userId,balance) values(#{userId},#{balance})")
    void save(Wallet wallet);


    @Update("update wallet set balance = balance + #{balance} where userId=#{userId}")
    void updateAddUserBalance(@Param("userId") int userId, @Param("balance") int balance);
    @Update("update wallet set cashCoupon = cashCoupon + #{cashCoupon} where userId=#{userId}")
    void updateAddCashCoupon(@Param("userId") int userId, @Param("cashCoupon") int cashCoupon);
    // 减少cash
    @Update("update wallet set balance = balance - #{balance} where userId=#{userId}")
    void updateReduceUserBalance(@Param("userId") int userId, @Param("balance") int balance);
    @Update("update wallet set cashCoupon = cashCoupon - #{cashCoupon} where userId=#{userId}")
    void updateReduceUserCoupon(@Param("userId") int userId, @Param("cashCoupon") int cashCoupon);
    // 设置交易密码
    @Update("update wallet set password=#{password} where userId=#{userId}")
    void updatePassword(@Param("userId") int userId, @Param("password") String password);

}
