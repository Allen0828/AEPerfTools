package com.aidejiayuan.gospel.service;

import com.aidejiayuan.gospel.Vo.User;

public interface UserService {


    /* 通过手机号查找注册用户 */
    User findUserByPhone(String phone);

    /* 通过id查找注册用户 */
    User findUserById(int id);

    /* 注册用户 */
    User insert(User user);

    /* 通过Id修改用户名 */
    void updateUsername(int id, String username);
    /* 通过Id修改性别 */
    void updateUserGender(int id, String gender);
    /* 通过Id修改信仰时长 */
    void updateUserFaithDate(int id, int faithDate);
    /* 通过Id修改教会 */
    void updateUserChurchName(int id, String name);
    void updateUserAvatar(int id, String avatar);

}
