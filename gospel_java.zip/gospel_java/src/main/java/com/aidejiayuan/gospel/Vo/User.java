package com.aidejiayuan.gospel.Vo;


import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@NoArgsConstructor
public class User {

    private int id;

    /* 手机号 */
    private String phone;
    /* 用户名 */
    private String username;
    /*  密码 */
    private String password;
    /* 管理员 */
    private int admin;

    private String avatar;
    private String gender;
    private String churchName;

    private Date createDate;

}
