package com.aidejiayuan.gospel.Vo;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class Wallet {

    // 钱包id
    public int id;
    // 用户id
    public int userId;
    // 余额
    private int balance;
    // 收到礼物的总价值
    private int cashCoupon;
    // device
    private String device;
    // 钱包密码
    private String password;


}
