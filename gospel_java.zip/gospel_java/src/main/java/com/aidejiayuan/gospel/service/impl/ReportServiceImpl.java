package com.aidejiayuan.gospel.service.impl;

import com.aidejiayuan.gospel.Vo.Report;
import com.aidejiayuan.gospel.mapper.ConfigureMapper;
import com.aidejiayuan.gospel.mapper.ReportMapper;
import com.aidejiayuan.gospel.service.ReportService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ReportServiceImpl implements ReportService {

    @Autowired
    ReportMapper reportMapper;


    @Override
    public void insert(Report report) {
        reportMapper.save(report);
    }



}
