package com.aidejiayuan.gospel.Vo;


import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@NoArgsConstructor
public class Report {

    private int id;
    private int userId;
    private String reportName;
    private String reportPhone;
    private String content;
    private String type;
    private Date createDate;

    public void setReport(int userId, String reportName, String reportPhone, String content, String type) {
        this.userId = userId;
        this.content = content;
        this.reportName = reportName;
        this.reportPhone = reportPhone;
        this.userId = userId;
        this.type = type;
    }
}
