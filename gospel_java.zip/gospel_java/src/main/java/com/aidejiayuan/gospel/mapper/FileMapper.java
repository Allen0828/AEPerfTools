package com.aidejiayuan.gospel.mapper;

import com.aidejiayuan.gospel.Vo.CourseCommentVo;
import com.aidejiayuan.gospel.Vo.File;
import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Repository;

import java.util.List;

@Mapper
@Repository
public interface FileMapper {

    @Select("select * from file where entityId=#{entityId} and usages=#{usages}")
    List<File> findFiles(@Param("entityId") int entityId, @Param("usages") String usages);

    @Select("select * from file where entityId=#{entityId} and usages=#{usages}")
    File findFile(@Param("entityId") int entityId, @Param("usages") String usages);

    @Insert("insert into file(entityId,fileName,hashName,fileExt,usages,imgWidth,imgHeight,duration,descs) values(#{entityId},#{fileName},#{hashName},#{fileExt},#{usages},#{imgWidth},#{imgHeight},#{duration},#{descs})")
    void addFile(File file);


}
