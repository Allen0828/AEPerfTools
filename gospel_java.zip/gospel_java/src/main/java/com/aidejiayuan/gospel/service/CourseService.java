package com.aidejiayuan.gospel.service;

import com.aidejiayuan.gospel.Vo.Course;
import com.aidejiayuan.gospel.Vo.CourseCommentVo;

import java.util.List;

public interface CourseService {

    public Course findCourseById(int id);

    public List<Course> loadAllCourses();

    public List<CourseCommentVo> loadCommentByLeeson(int lessonId, int userId);

    public List<CourseCommentVo> loadCommentsById(int commentId);

    public int insert(CourseCommentVo vo);

    public void addLikeCount(int id);
    public void deleteLikeCount(int id);

    public void addCommentCount(int id);
}
