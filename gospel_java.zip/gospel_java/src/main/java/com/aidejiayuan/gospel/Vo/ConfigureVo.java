package com.aidejiayuan.gospel.Vo;

import lombok.Data;

@Data
public class ConfigureVo {

    private long id;
    private String title;
    private String img;
    private String type;
    private String itemType;
    // 如果是pin 此为pinId 如果是folder 此为folderId
    private long itemId;
    private String url;
    // 如果是小程序 小程序path
    private String miniProgPath;

}
