package com.aidejiayuan.gospel.service.impl;

import com.aidejiayuan.gospel.Vo.*;
import com.aidejiayuan.gospel.mapper.CourseMapper;
import com.aidejiayuan.gospel.mapper.UserMapper;
import com.aidejiayuan.gospel.service.CourseService;
import com.aidejiayuan.gospel.service.LessonService;
import com.aidejiayuan.gospel.service.LikeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class CourseServiceImpl implements CourseService {

    @Autowired
    CourseMapper courseMapper;
    @Autowired
    LessonService lessonService;
    @Autowired
    UserMapper userMapper;
    @Autowired
    LikeService likeService;

    @Override
    public Course findCourseById(int id) {
        Course vo = courseMapper.findCourseById(id);
        List<Lesson> lessons = lessonService.findLessonsByCourseId(id);
        vo.setLessonVos(lessons);
        return vo;
    }

    @Override
    public List<Course> loadAllCourses() {
        List<Course> vos = courseMapper.loadAllCourses();
        for (Course item: vos) {
            UserVisibleInfo user = new UserVisibleInfo();
            user.setUserVo(userMapper.findUserById(item.getUserId()));
            item.setUserVo(user);
            List<Lesson> lessons = lessonService.findLessonsByCourseId(item.getId());
            item.setLessonVos(lessons);
        }
        return vos;
    }

    @Override
    public List<CourseCommentVo> loadCommentByLeeson(int lessonId, int userId) {
        List<CourseCommentVo> vos = courseMapper.loadCommentByLeeson(lessonId);
        for (CourseCommentVo item: vos) {
            UserVisibleInfo user = new UserVisibleInfo();
            int itemUserId = item.getSubmitId();
            user.setUserVo(userMapper.findUserById(itemUserId));
            item.setSubmitUserVo(user);
            item.setLiked(likeService.isLikeComment(userId, item.getId()));
            CourseCommentVo timeVo = courseMapper.findCommentByMaxTime(item.getId());
            if (timeVo != null) {
                UserVisibleInfo timeUser = new UserVisibleInfo();
                int timeUserId = timeVo.getSubmitId();
                timeUser.setUserVo(userMapper.findUserById(timeUserId));
                timeVo.setSubmitUserVo(timeUser);
                item.setTopSubCommentVo(timeVo);
            }
        }
        return vos;
    }

    @Override
    public List<CourseCommentVo> loadCommentsById(int commentId) {
        List<CourseCommentVo> vos = courseMapper.loadCommentsById(commentId, "COMMENT");
        for (CourseCommentVo item: vos) {
            UserVisibleInfo user = new UserVisibleInfo();
            int itemUserId = item.getSubmitId();
            user.setUserVo(userMapper.findUserById(itemUserId));
            item.setSubmitUserVo(user);
        }
        return vos;
    }

    @Override
    public int insert(CourseCommentVo vo) {
        return courseMapper.save(vo);
    }

    @Override
    public void addLikeCount(int id) { courseMapper.addLikeCount(id); }
    @Override
    public void deleteLikeCount(int id) { courseMapper.deleteLikeCount(id); }

    @Override
    public void addCommentCount(int id) { courseMapper.addCommentCount(id); }


}
