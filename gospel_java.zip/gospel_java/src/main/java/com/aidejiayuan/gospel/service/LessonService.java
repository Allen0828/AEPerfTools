package com.aidejiayuan.gospel.service;

import com.aidejiayuan.gospel.Vo.Lesson;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

public interface LessonService {

    Lesson findLessonById(int id);

    List<Lesson> findLessonsByCourseId(int courseId);


}
