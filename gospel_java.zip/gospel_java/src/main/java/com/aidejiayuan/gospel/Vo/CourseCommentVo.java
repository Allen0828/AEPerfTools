package com.aidejiayuan.gospel.Vo;


import lombok.Data;

import java.util.Date;

@Data
public class CourseCommentVo {

    private int id;
    private int submitId;
    // commentId
    private Integer entityId;
    private Integer lessonId;
    private String type;
    private String content;
    private Integer replyToId;
    private Integer replyToUserId;
    private String replyToUserName;

    private int commentCount;
    private int likeCount;
    private boolean liked;
    private boolean top;
    private Date createDate;

    private UserVisibleInfo submitUserVo;
    // 子评论信息 在用于Cell是 只展示一个
    private CourseCommentVo topSubCommentVo;


    public void setComment(int submitId, int entityId, String type, String content) {
        this.submitId = submitId;
        this.entityId = entityId;
        this.type = type;
        this.content = content;
    }
    public void setLessonComment(int submitId, int lessonId, String type, String content) {
        this.submitId = submitId;
        this.lessonId = lessonId;
        this.type = type;
        this.content = content;
    }
    public void setReplyComment(int submitId, int entityId, String type, String content, String replyToUserName, int replyToId, int replyToUserId) {
        this.submitId = submitId;
        this.entityId = entityId;
        this.type = type;
        this.content = content;
        this.replyToUserName = replyToUserName;
        this.replyToId = replyToId;
        this.replyToUserId = replyToUserId;
    }
}
