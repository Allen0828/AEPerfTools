package com.aidejiayuan.gospel.service;

import com.aidejiayuan.gospel.Vo.Feed;

import java.util.List;

public interface FeedService {

    Feed findFeedById(int id);

    List<Feed> loadFeedByAuthorId(int id);

    // 更新Feed数据
    void updateFeedScore(int id, int score);
    void updateFeedReward(int id);

    // 发布
    int addFeed(Feed vo);

}
