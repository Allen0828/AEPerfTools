package com.aidejiayuan.gospel.Vo;


import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Data
public class Lesson {

    private int id;
    private int courseId;
    private int unitId;
    private String title;
    private String descs;
    private String coverImg;
    private int free;
    private String type;
    private String url;

    private File fileVo;
}
