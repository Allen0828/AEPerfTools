package com.aidejiayuan.gospel.mapper;


import com.aidejiayuan.gospel.Vo.ConfigureVo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

import java.util.List;

@Mapper
@Repository
public interface ConfigureMapper {

    @Select("select * from configure where type=#{type} order by id desc")
    List<ConfigureVo> loadByType(@Param("type") String type);


}
