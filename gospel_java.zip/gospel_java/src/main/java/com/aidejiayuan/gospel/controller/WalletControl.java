package com.aidejiayuan.gospel.controller;


import com.aidejiayuan.gospel.Vo.Wallet;
import com.aidejiayuan.gospel.service.WalletService;
import com.aidejiayuan.gospel.tools.annotation.UserLoginToken;
import com.aidejiayuan.gospel.tools.utils.DataMap;
import com.aidejiayuan.gospel.tools.utils.IOSVerifyUtil;
import com.alibaba.fastjson.JSONObject;
import com.auth0.jwt.JWT;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
@RestController
public class WalletControl {

    @Autowired
    WalletService walletService;

    /* 获取用户钱包信息 */
    @UserLoginToken
    @GetMapping("api/wallet/getMyWallet")
    public DataMap getMyWallet(@RequestHeader("token") String token) {
        int userId = Integer.parseInt(JWT.decode(token).getAudience().get(0));
        if (userId < 1) { return DataMap.error("没有此用户"); }
        Wallet vo = walletService.findWalletByUserId(userId);
        if (vo.id < 1) { return DataMap.error("没有此用户"); }
        return DataMap.success(vo);
    }

    /* 提现申请 */
    @UserLoginToken
    @PostMapping("api/wallet/withdrawal")
    public DataMap withdrawal(@RequestHeader("token") String token, @RequestBody Map<String, Object> map) {
        int userId = Integer.parseInt(JWT.decode(token).getAudience().get(0));
        String password = (String) map.get("code");
        Wallet vo = walletService.findWalletByUserId(userId);
        if (vo.getPassword() != password) {
            return DataMap.error("交易密码不正确");
        }

        return DataMap.success("1");
    }

    // 修改交易密码
    @UserLoginToken
    @PostMapping("api/wallet/updateWalletCode")
    public DataMap updateWalletCode(@RequestHeader("token") String token, @RequestBody Map<String, Object> map) {
        int userId = Integer.parseInt(JWT.decode(token).getAudience().get(0));
        String password = (String) map.get("code");
        Wallet vo = walletService.findWalletByUserId(userId);
        if (vo != null && password != null) {
            walletService.updatePassword(userId, password);
            return DataMap.success("OK");
        }
        return DataMap.error("检查参数");
    }


    // 验证用户是否充值成功 userId 从参数中获取 防止用户token临时过期
    @PostMapping("api/wallet/receiptValidation")
    public DataMap receiptValidation(@RequestBody Map<String, Object> map) {
        if (!map.containsKey("userId")) {
            return DataMap.error("用户未登陆");
        }
        String transactionId = (String) map.get("transactionId");
        String receiptData = (String) map.get("receiptData");
        int amount = (int) map.get("amount");
        int userId = (int) map.get("userId");
        // 优先生产环境验证
        String verifyResult = IOSVerifyUtil.buyAppVerify(receiptData, 1);
        if (verifyResult == null) {
            return DataMap.error("苹果验证失败，返回数据为空");
        } else {
            JSONObject appleReturn = JSONObject.parseObject(verifyResult);
            String states = appleReturn.getString("status");
            //无数据则沙箱环境验证
            if ("21007".equals(states)) {
                verifyResult = IOSVerifyUtil.buyAppVerify(receiptData, 0);
                log.info("沙盒环境，苹果平台返回JSON:" + verifyResult);
                appleReturn = JSONObject.parseObject(verifyResult);
                states = appleReturn.getString("status");
            }
            // 前端所提供的收据是有效的    验证成功
            if (states.equals("0")) {
                String receipt = appleReturn.getString("receipt");
                JSONObject returnJson = JSONObject.parseObject(receipt);
                String inApp = returnJson.getString("in_app");
                List<HashMap> inApps = JSONObject.parseArray(inApp, HashMap.class);
                if (!CollectionUtils.isEmpty(inApps)) {
                    ArrayList<String> transactionIds = new ArrayList<String>();
                    for (HashMap app : inApps) {
                        transactionIds.add((String) app.get("transaction_id"));
                    }
                    //交易列表包含当前交易，则认为交易成功
                    if (transactionIds.contains(transactionId)) {
                        //处理业务逻辑  如果 states == 21007 沙盒测试 不写入数据库
                        walletService.updateBalance(userId, amount, 1);
                        return DataMap.success("充值成功");
                    }
                    return DataMap.error("当前交易不在交易列表中");
                }
                return DataMap.error("未能获取获取到交易列表");
            } else {
                return DataMap.error("支付失败，错误码：" + states);
            }
        }
    }

}
