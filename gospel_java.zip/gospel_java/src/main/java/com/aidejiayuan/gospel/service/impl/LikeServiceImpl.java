package com.aidejiayuan.gospel.service.impl;

import com.aidejiayuan.gospel.Vo.Feed;
import com.aidejiayuan.gospel.Vo.File;
import com.aidejiayuan.gospel.Vo.Like;
import com.aidejiayuan.gospel.Vo.UserVisibleInfo;
import com.aidejiayuan.gospel.mapper.FeedMapper;
import com.aidejiayuan.gospel.mapper.LikeMapper;
import com.aidejiayuan.gospel.service.LikeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class LikeServiceImpl implements LikeService {

    @Autowired
    LikeMapper likeMapper;
    @Autowired
    FeedMapper feedMapper;

    @Override
    public void insert(Like like) { likeMapper.save(like); }

    @Override
    public Boolean isLikeFeed(int userId, int feedId) {
        feedMapper.updateLikeCount(feedId);
        return likeMapper.isLikeFeed(userId, feedId);
    }
    @Override
    public Boolean isLikeComment(int userId, int commentId) { return likeMapper.isLikeComment(userId, commentId); }

    @Override
    public void unLikeFeed(int userId, int feedId) { likeMapper.unLikeFeed(userId, feedId); }
    @Override
    public void unLikeComment(int userId, int commentId) { likeMapper.unLikeComment(userId, commentId); }

    @Override
    public List<Like> loadUserLikeFeeds(int userId) {
        List<Like> likes = likeMapper.loadUserLikes(userId, "FEED");
        for (Like item: likes) {
            Feed vo = feedMapper.findFeedById(item.feedId);
            item.setFeedVo(vo);
        }
        return likes;
    }


}
