package com.aidejiayuan.gospel.mapper;


import com.aidejiayuan.gospel.Vo.GiftVo;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

import java.util.List;

@Mapper
@Repository
public interface GiftMapper {


    @Insert("insert into gift(userId,beneficiaryId,type,feedId,lessonId,count,price) values(#{userId},#{beneficiaryId},#{type},#{feedId},#{lessonId},#{count},#{price})")
    void insert(GiftVo gift);

    @Select("select * from gift where feedId=#{feedId} order by id desc")
    List<GiftVo> loadFeedGiftById(int id);

    @Select("select * from gift where beneficiaryId=#{beneficiaryId} order by id desc")
    List<GiftVo> loadGiftsByBeneficiaryId(int beneficiaryId);


}
