package com.aidejiayuan.gospel;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;

@SpringBootApplication
public class GospelApplication extends SpringBootServletInitializer {

    public static void main(String[] args) {
        SpringApplication.run(GospelApplication.class, args);
    }

    // 正式环境移除内置Tomcat
//    @Override
//    protected SpringApplicationBuilder configure(SpringApplicationBuilder builder) {
//        return builder.sources(GospelApplication.class);
//    }

}

