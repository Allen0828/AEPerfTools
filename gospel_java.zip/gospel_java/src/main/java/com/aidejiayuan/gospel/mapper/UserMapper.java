package com.aidejiayuan.gospel.mapper;


import com.aidejiayuan.gospel.Vo.UserVisibleInfo;
import org.apache.ibatis.annotations.*;
import com.aidejiayuan.gospel.Vo.User;
import org.springframework.stereotype.Repository;

@Mapper
@Repository
public interface UserMapper {


    @Select("select * from user where phone=#{phone}")
    User findUserByPhone(@Param("phone") String phone);

    @Select("select * from user where id=#{id}")
    User findUserById(@Param("id") int id);

    
    @Insert("insert into user(phone,username,password,gender,avatar) values(#{phone},#{username},#{password},#{gender},#{avatar})")
    void save(User user);

    @Update("update user set username=#{username} where id=#{id}")
    void updateUsername(@Param("id") int id, @Param("username") String username);
    @Update("update user set gender=#{gender} where id=#{id}")
    void updateUserGender(@Param("id") int id, @Param("gender") String gender);
    @Update("update user set faithDate=#{faithDate} where id=#{id}")
    void updateUserFaithDate(@Param("id") int id, @Param("faithDate") int faithDate);
    @Update("update user set churchName=#{churchName} where id=#{id}")
    void updateUserChurchName(@Param("id") int id, @Param("churchName") String churchName);
    @Update("update user set avatar=#{avatar} where id=#{id}")
    void updateUserAvatar(@Param("id") int id, @Param("avatar") String avatar);

}
