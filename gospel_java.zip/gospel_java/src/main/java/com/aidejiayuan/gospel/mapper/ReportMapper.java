package com.aidejiayuan.gospel.mapper;


import com.aidejiayuan.gospel.Vo.Report;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

@Mapper
@Repository
public interface ReportMapper {

    @Insert("insert into report(userId,reportName,reportPhone,content,type) values(#{userId},#{reportName},#{reportPhone},#{content},#{type})")
    void save(Report report);

}

