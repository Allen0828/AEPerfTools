package com.aidejiayuan.gospel.mapper;


import com.aidejiayuan.gospel.Vo.Like;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

import java.util.List;

@Mapper
@Repository
public interface LikeMapper {

    @Insert("insert into likes(userId,feedId,courseId,lessonId,type,commentId) values(#{userId},#{feedId},#{courseId},#{lessonId},#{type},#{commentId})")
    void save(Like like);

    // 查找用户是否喜欢了feed
    @Select("select count(1) from likes where feedId=#{feedId} and userId=#{userId}")
    Boolean isLikeFeed(int userId, int feedId);
    // 查找用户是否喜欢了comment
    @Select("select count(1) from likes where commentId=#{commentId} and userId=#{userId}")
    Boolean isLikeComment(int userId, int commentId);

    // 取消喜欢Feed
    @Delete("delete from likes where feedId=#{feedId} and userId=#{userId}")
    void unLikeFeed(int userId, int feedId);
    // 取消喜欢Comment
    @Delete("delete from likes where commentId=#{commentId} and userId=#{userId}")
    void unLikeComment(int userId, int commentId);

    // 获取用户的所有喜欢
    @Select("select * from likes where userId=#{userId} and type=#{type} order by id desc")
    List<Like> loadUserLikes(int userId, String type);

}
