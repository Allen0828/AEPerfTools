package com.aidejiayuan.gospel.Vo;


import lombok.Data;

@Data
public class File {

    private int id;
    // 主体Id
    private int entityId;
    // 文件名 图片时和hashName一样 视频时代表了视频封面图
    private String fileName;
    // 如果是视频 视频封面=fileName
    private String hashName;
    private String usages;
    private int imgWidth;
    private int imgHeight;
    private String descs;
    // 秒数
    private int duration;
    // 存入时的类型 image/* / video/mp4
    private String fileExt;

    private String fileType;

    public String getFileType() {
        if (fileExt.contains("image")) {
            return "IMAGE";
        }
        return "VIDEO";
    }

    public void setFile(int entityId, String fileName, String hashName, Integer imgWidth, Integer imgHeight, String descr, String fileExt, Integer duration, String usages) {
        this.entityId = entityId;
        this.fileName = fileName;
        this.hashName = hashName;
        this.imgWidth = imgWidth;
        this.imgHeight = imgHeight;
        this.descs = descr;
        this.fileExt = fileExt;
        this.duration = duration;
        this.usages = usages;
    }


}
