package com.aidejiayuan.gospel.Vo;


import lombok.Data;

import java.util.Date;

@Data
public class GiftVo {

    // 送出的人
    private int userId;
    // 收到的人
    private int beneficiaryId;
    private String type;
    private int feedId;
    private int lessonId;
    private int count;
    private int price;
    private Date createDate;

    // 赠送人信息
    private UserVisibleInfo userVo;

    public void setFeedGift(int userId, int beneficiaryId, int feedId, int count) {
        this.userId = userId;
        this.beneficiaryId = beneficiaryId;
        this.feedId = feedId;
        this.count = count;
        this.type = "FEED";
        // 目前只有一个礼物 单价1元
        this.price = 1;
    }

}
