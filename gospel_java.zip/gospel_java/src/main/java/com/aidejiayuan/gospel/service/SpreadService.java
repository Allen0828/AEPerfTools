package com.aidejiayuan.gospel.service;

import com.aidejiayuan.gospel.Vo.ConfigureVo;
import com.aidejiayuan.gospel.Vo.Course;
import com.aidejiayuan.gospel.Vo.Feed;

import java.util.List;

public interface SpreadService {

    public List<Feed> loadRecommendFeed();

    public List<ConfigureVo> loadByType(String type);

    // type=0 加载最新feed  type=1 加载所有的包含待审核
    List<Feed> loadNewFeed(int type);

}
