package com.aidejiayuan.gospel.controller;


import com.aidejiayuan.gospel.Vo.Like;
import com.aidejiayuan.gospel.service.CourseService;
import com.aidejiayuan.gospel.service.LikeService;
import com.aidejiayuan.gospel.tools.annotation.UserLoginToken;
import com.aidejiayuan.gospel.tools.utils.DataMap;
import com.auth0.jwt.JWT;
import com.github.pagehelper.PageHelper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@Slf4j
@RestController
public class LikeControl {

    @Autowired
    LikeService likeService;
    @Autowired
    CourseService courseService;

    @UserLoginToken
    @GetMapping("api/like/loadMyLikeFeeds")
    public DataMap loadMyLikeFeeds(@RequestHeader("token") String token, @RequestParam("page") int page) {
        int userId = Integer.parseInt(JWT.decode(token).getAudience().get(0));
        if (userId < 1) {
            return DataMap.error("检查参数");
        }
        int pageNum = page;
        if (page == 0) { pageNum = 1; }
        int pageSize = 20;
        PageHelper.startPage(pageNum, pageSize);
        List<Like> vos = likeService.loadUserLikeFeeds(userId);
        return DataMap.success(vos);
    }

    @UserLoginToken
    @GetMapping("api/like/likeFeed")
    public DataMap likeFeed(@RequestHeader("token") String token, @RequestParam("id") int id) {
        int userId = Integer.parseInt(JWT.decode(token).getAudience().get(0));
        if (userId < 1 || id < 1) { return DataMap.error("检查参数"); }
        Like vo = new Like();
        vo.setFeed(userId, id);
        likeService.insert(vo);
        return DataMap.success("OK");
    }

    @UserLoginToken
    @GetMapping("api/like/unLikeFeed")
    public DataMap unLikeFeed(@RequestHeader("token") String token, @RequestParam("id") int id) {
        int userId = Integer.parseInt(JWT.decode(token).getAudience().get(0));
        if (userId < 1 || id < 1) { return DataMap.error("检查参数"); }
        likeService.unLikeFeed(userId, id);
        return DataMap.success("OK");
    }

    @UserLoginToken
    @GetMapping("api/like/likeComment")
    public DataMap likeComment(@RequestHeader("token") String token, @RequestParam("id") int id) {
        int userId = Integer.parseInt(JWT.decode(token).getAudience().get(0));
        if (userId < 1 || id < 1) { return DataMap.error("检查参数"); }
        Like vo = new Like();
        vo.setComment(userId, id);
        likeService.insert(vo);
        courseService.addLikeCount(id);
        return DataMap.success("OK");
    }

    @UserLoginToken
    @GetMapping("api/like/unLikeComment")
    public DataMap unLikeComment(@RequestHeader("token") String token, @RequestParam("id") int id) {
        int userId = Integer.parseInt(JWT.decode(token).getAudience().get(0));
        if (userId < 1 || id < 1) { return DataMap.error("检查参数"); }
        likeService.unLikeFeed(userId, id);
        courseService.deleteLikeCount(id);
        return DataMap.success("OK");
    }

}
