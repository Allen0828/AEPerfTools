package com.aidejiayuan.gospel.service;

import com.aidejiayuan.gospel.Vo.Wallet;

public interface WalletService {

    Wallet findWalletByUserId(int userId);
    /* 注册钱包 */
    Wallet insert(Wallet wallet);

    void updateBalance(int userId, int balance, int type);
    void updateCashCoupon(int userId, int cashCoupon, int type);
    void updatePassword(int userId, String  password);


}
