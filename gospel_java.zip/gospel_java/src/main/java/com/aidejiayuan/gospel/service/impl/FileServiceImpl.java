package com.aidejiayuan.gospel.service.impl;

import com.aidejiayuan.gospel.Vo.File;
import com.aidejiayuan.gospel.mapper.FileMapper;
import com.aidejiayuan.gospel.service.FileService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class FileServiceImpl implements FileService {

    @Autowired
    FileMapper fileMapper;

    @Override
    public List<File> findFiles(int entityId, String usages){ return fileMapper.findFiles(entityId, usages); }
    @Override
    public  File findFile(int entityId, String usages) { return fileMapper.findFile(entityId, usages); }


    @Override
    public void addFile(File vo) { fileMapper.addFile(vo); }

}
