package com.aidejiayuan.gospel.service;


import com.aidejiayuan.gospel.Vo.User;
import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import jdk.nashorn.internal.parser.Token;
import org.springframework.stereotype.Service;

import java.util.Date;

@Service("TokenService")
public class TokenService {
    // 过期时间，单位毫秒 一年有效期
    private static final long EXPIRE_TIME = 365*24*60*60*1000;

    public String getToken(User user) {
        // 生成过期时间
        Date date = new Date(System.currentTimeMillis()+EXPIRE_TIME);
        // 以 password 作为 token 的密钥
        String token = JWT.create().withAudience(String.valueOf(user.getId()))
                .withExpiresAt(date)
                .sign(Algorithm.HMAC256(user.getPassword()));
        return token;
    }
}
