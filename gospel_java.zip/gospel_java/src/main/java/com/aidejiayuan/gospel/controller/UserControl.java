package com.aidejiayuan.gospel.controller;


import com.aidejiayuan.gospel.Vo.*;
import com.aidejiayuan.gospel.service.FeedService;
import com.aidejiayuan.gospel.service.LikeService;
import com.aidejiayuan.gospel.service.UserService;
import com.aidejiayuan.gospel.service.WalletService;
import com.aidejiayuan.gospel.tools.annotation.UserLoginToken;
import com.aidejiayuan.gospel.tools.utils.DataMap;
import com.auth0.jwt.JWT;
import com.github.pagehelper.PageHelper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@Slf4j
@RestController
public class UserControl {

    @Autowired
    UserService userService;
    @Autowired
    WalletService walletService;
    @Autowired
    LikeService likeService;
    @Autowired
    FeedService feedService;

    /* 根据id查找用户 */
    @GetMapping("api/user/findUser")
    public DataMap findUserById(@RequestParam("id") int id) {
        User vo = userService.findUserById(id);
        if (vo.getId() < 1) { return DataMap.error("没有此用户"); }
        UserVisibleInfo info = new UserVisibleInfo();
        info.setUserVo(vo);
        return DataMap.success(info);
    }

    /* 获取个人信息 */
    @UserLoginToken
    @GetMapping("api/user/getMyUserInfo")
    public DataMap getMyUserInfo(@RequestHeader("token") String token) {
        int userId = Integer.parseInt(JWT.decode(token).getAudience().get(0));
        if (userId < 1) { return DataMap.error("没有此用户"); }
        User vo = userService.findUserById(userId);
        UserVisibleInfo info = new UserVisibleInfo();
        info.setUserVo(vo);
        Wallet wa = walletService.findWalletByUserId(userId);
        info.setUserWallet(wa);
        List<Like> likes = likeService.loadUserLikeFeeds(userId);
        info.setLikeCount(likes.size());
        List<Feed> feeds = feedService.loadFeedByAuthorId(userId);
        info.setPostCount(feeds.size());
        return DataMap.success(info);
    }

    /* 修改用户名 */
    @UserLoginToken
    @PostMapping("api/user/updateUsername")
    public DataMap updateUsername(@RequestHeader("token") String token, @RequestBody Map<String, Object> map) {
        String name = (String) map.get("name");
        int userId = Integer.parseInt(JWT.decode(token).getAudience().get(0));
        if (name == null || userId < 1) {
            return DataMap.error("不能设置空名字");
        }
        userService.updateUsername(userId,name);
        return DataMap.success("OK");
    }

    /* 修改用户性别 */
    @UserLoginToken
    @PostMapping("api/user/updateGender")
    public DataMap updateGender(@RequestHeader("token") String token, @RequestBody Map<String, Object> map) {
        String gender = (String) map.get("gender");
        int userId = Integer.parseInt(JWT.decode(token).getAudience().get(0));
        if (gender == null || userId < 1) {
            return DataMap.error("请检查字段");
        }
        userService.updateUserGender(userId, gender);
        return DataMap.success("OK");
    }

    /* 修改信仰时长 */
    @UserLoginToken
    @PostMapping("api/user/updateFaithDate")
    public DataMap updateFaithDate(@RequestHeader("token") String token, @RequestBody Map<String, Object> map) {
        int date = (int) map.get("faithDate");
        int userId = Integer.parseInt(JWT.decode(token).getAudience().get(0));
        if (date == 0 || userId < 1) {
            return DataMap.error("请检查字段");
        }
        userService.updateUserFaithDate(userId, date);
        return DataMap.success("OK");
    }

    /* 修改教会名称 */
    @UserLoginToken
    @PostMapping("api/user/updateChurchName")
    public DataMap updateUserChurchName(@RequestHeader("token") String token, @RequestBody Map<String, Object> map) {
        String name = (String) map.get("churchName");
        int userId = Integer.parseInt(JWT.decode(token).getAudience().get(0));
        if (name == null || userId < 1) {
            return DataMap.error("请检查字段");
        }
        userService.updateUserChurchName(userId, name);
        return DataMap.success("OK");
    }
    /* 修改头像 */
    @UserLoginToken
    @PostMapping("api/user/updateAvatar")
    public DataMap updateUserAvatar(@RequestHeader("token") String token, @RequestBody Map<String, Object> map) {
        String avatar = (String) map.get("avatar");
        int userId = Integer.parseInt(JWT.decode(token).getAudience().get(0));
        if (avatar == null || userId < 1) {
            return DataMap.error("请检查字段");
        }
        userService.updateUserAvatar(userId,avatar);
        return DataMap.success("OK");
    }

    @UserLoginToken
    @GetMapping("api/user/loadFeedByAuthorId")
    public DataMap loadMyPostFeed(@RequestHeader("token") String token, @RequestParam("page") int page) {
        int userId = Integer.parseInt(JWT.decode(token).getAudience().get(0));
        if (userId < 1) {
            return DataMap.error("检查参数");
        }
        int pageNum = page;
        if (page == 0) { pageNum = 1; }
        int pageSize = 20;
        PageHelper.startPage(pageNum, pageSize);
        List<Feed> feeds = feedService.loadFeedByAuthorId(userId);
        return DataMap.success(feeds);
    }

}
