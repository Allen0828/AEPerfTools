package com.aidejiayuan.gospel.Vo;

import lombok.Data;

@Data
public class Like {

    public int id;
    public Integer userId;
    public Integer feedId;
    public Integer courseId;
    public Integer lessonId;
    public Integer commentId;
    public String type;

    public Feed feedVo;

    public void setFeed(int userId, int feedId) {
        this.setUserId(userId);
        this.setFeedId(feedId);
        this.setType("FEED");
    }

    public void setComment(Integer userId, Integer commentId) {
        this.setUserId(userId);
        this.setCommentId(commentId);
        this.setType("COURSE_COMMENT");
    }

}
