package com.aidejiayuan.gospel.service.impl;

import com.aidejiayuan.gospel.Vo.User;
import com.aidejiayuan.gospel.Vo.Wallet;
import com.aidejiayuan.gospel.mapper.WalletMapper;
import com.aidejiayuan.gospel.service.WalletService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class WalletServiceImpl implements WalletService {

    @Autowired
    WalletMapper walletMapper;

    @Override
    public Wallet findWalletByUserId(int userId) { return walletMapper.findWalletByUserId(userId); }

    @Override
    public Wallet insert(Wallet wallet) {
        walletMapper.save(wallet);
        return wallet;
    }

    // type=0 减少数量
    @Override
    public void updateBalance(int userId, int balance, int type) {
        if (type == 0) {
            walletMapper.updateReduceUserBalance(userId, balance);
        } else {
            walletMapper.updateAddUserBalance(userId, balance);
        }
    }
    @Override
    public void updateCashCoupon(int userId, int cashCoupon, int type) {
        if (type == 0) {
            walletMapper.updateReduceUserCoupon(userId, cashCoupon);
        } else {
            walletMapper.updateAddCashCoupon(userId, cashCoupon);
        }
    }
    @Override
    public void updatePassword(int userId, String  password) {
        walletMapper.updatePassword(userId, password);
    }

}
