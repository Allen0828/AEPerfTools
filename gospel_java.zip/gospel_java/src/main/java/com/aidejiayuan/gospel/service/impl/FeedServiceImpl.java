package com.aidejiayuan.gospel.service.impl;


import com.aidejiayuan.gospel.Vo.Feed;
import com.aidejiayuan.gospel.Vo.File;
import com.aidejiayuan.gospel.Vo.UserVisibleInfo;
import com.aidejiayuan.gospel.mapper.FeedMapper;
import com.aidejiayuan.gospel.mapper.UserMapper;
import com.aidejiayuan.gospel.service.FeedService;
import com.aidejiayuan.gospel.service.FileService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class FeedServiceImpl implements FeedService {

    @Autowired
    FeedMapper feedMapper;
    @Autowired
    UserMapper userMapper;
    @Autowired
    FileService fileService;

    @Override
    public Feed findFeedById(int id) {
        feedMapper.updatePvCount(id);
        return feedMapper.findFeedById(id);
    }


    @Override
    public List<Feed> loadFeedByAuthorId(int id) {
        List<Feed> feeds = feedMapper.loadFeedByAuthorId(id);
        for (Feed item: feeds) {
            feedMapper.updatePvCount(item.getId());
            UserVisibleInfo user = new UserVisibleInfo();
            user.setUserVo(userMapper.findUserById(item.getAuthorId()));
            item.setAuthor(user);
            List<File> files = fileService.findFiles(item.getId(),"FEED");
            item.setFileVos(files);
        }
        return feeds;
    }

    @Override
    public void updateFeedScore(int id, int score) {
        feedMapper.updateFeedScore(id, score);
    }
    @Override
    public void updateFeedReward(int id) {
        feedMapper.updateRewardCount(id);
    }


    @Override
    public int addFeed(Feed vo) { return feedMapper.addFeed(vo); }

}
