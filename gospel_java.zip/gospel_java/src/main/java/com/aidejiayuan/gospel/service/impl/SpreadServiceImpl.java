package com.aidejiayuan.gospel.service.impl;


import com.aidejiayuan.gospel.Vo.*;
import com.aidejiayuan.gospel.mapper.ConfigureMapper;
import com.aidejiayuan.gospel.mapper.CourseMapper;
import com.aidejiayuan.gospel.mapper.FeedMapper;
import com.aidejiayuan.gospel.mapper.UserMapper;
import com.aidejiayuan.gospel.service.CourseService;
import com.aidejiayuan.gospel.service.FileService;
import com.aidejiayuan.gospel.service.SpreadService;
import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Service
public class SpreadServiceImpl implements SpreadService {

    @Autowired
    FeedMapper feedMapper;
    @Autowired
    UserMapper userMapper;
    @Autowired
    FileService fileService;
    @Autowired
    ConfigureMapper configureMapper;

    public List<Feed> loadRecommendFeed() {
        List<Feed> all = feedMapper.loadAllFeed();
        for (Feed item: all) {
            feedMapper.updatePvCount(item.getId());
            UserVisibleInfo user = new UserVisibleInfo();
            user.setUserVo(userMapper.findUserById(item.getAuthorId()));
            item.setAuthor(user);
            List<File> files = fileService.findFiles(item.getId(),"FEED");
            item.setFileVos(files);
        }
        return all;
    }

    public List<ConfigureVo> loadByType(String type) {
        return configureMapper.loadByType(type);
    }

    @Override
    public List<Feed> loadNewFeed(int type) {
        if (type == 0) {
            List<Feed> all = feedMapper.loadNewFeed();
            for (Feed item: all) {
                feedMapper.updatePvCount(item.getId());
                UserVisibleInfo user = new UserVisibleInfo();
                user.setUserVo(userMapper.findUserById(item.getAuthorId()));
                item.setAuthor(user);
                List<File> files = fileService.findFiles(item.getId(),"FEED");
                item.setFileVos(files);
            }
            return all;
        } else {
            List<Feed> all = feedMapper.loadExamineFeed();
            for (Feed item: all) {
                feedMapper.updatePvCount(item.getId());
                UserVisibleInfo user = new UserVisibleInfo();
                user.setUserVo(userMapper.findUserById(item.getAuthorId()));
                item.setAuthor(user);
                List<File> files = fileService.findFiles(item.getId(),"FEED");
                item.setFileVos(files);
            }
            return all;
        }
    }

}
